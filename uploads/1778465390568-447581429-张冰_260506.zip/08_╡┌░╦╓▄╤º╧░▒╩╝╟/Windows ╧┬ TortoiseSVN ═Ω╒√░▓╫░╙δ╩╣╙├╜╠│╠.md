---
date: 2026-04-30
tags:
  - TortoiseSVN
  - SVN
  - 版本控制
  - 工具安装
  - Windows
aliases:
  - SVN安装教程
  - TortoiseSVN使用指南
---

# 🐢 Windows 下 TortoiseSVN 完整安装与使用教程

> [!abstract] 📋 文档概述
> TortoiseSVN 是 Windows 平台上最流行的 SVN 客户端工具，提供图形化界面和命令行工具。本教程涵盖下载、安装、环境配置及命令行使用方法。

---

## 📑 目录

- [[#一、下载 TortoiseSVN]]
- [[#二、安装 TortoiseSVN]]
- [[#三、验证安装与环境变量配置]]
- [[#四、命令行使用指南]]
- [[#五、常用 SVN 命令速查]]
- [[#六、常见问题解决]]

---

## 一、下载 TortoiseSVN

### 1️⃣ 访问官网

打开浏览器，访问 TortoiseSVN 官网：

> [!info] 🌐 下载地址
> **官网**：https://sourceforge.net/projects/tortoisesvn/

### 2️⃣ 选择对应版本

根据你的系统选择正确的安装包：

| 系统类型 | 下载文件 | 说明 |
|:---------|:---------|:-----|
| **64位系统** | `TortoiseSVN-xxx-x64.msi` | 大多数现代电脑 |
| **32位系统** | `TortoiseSVN-xxx-x86.msi` | 老旧电脑 |

> [!tip] 💡 如何查看系统位数
> 右键"此电脑" → 属性 → 查看"系统类型"

---

## 二、安装 TortoiseSVN

> [!warning] ⚠️ 重要提示
> 安装过程中**必须勾选命令行工具**，否则无法在 CMD 中使用 `svn` 命令！

### 步骤 1：运行安装程序

双击下载的 `.msi` 安装包，点击 **Next** 开始安装。

### 步骤 2：接受许可协议

勾选 **"I accept the terms in the License Agreement"**，点击 **Next**。

### 步骤 3：选择安装路径

保持默认路径 `C:\Program Files\TortoiseSVN` 或自定义路径，点击 **Next**。

### 步骤 4：【关键】选择功能组件

> [!important] 🔑 这是最重要的一步！

在组件选择页面：

1. 找到 **"command line client tools"** 选项
2. 点击该选项左侧的图标
3. 选择 **"Will be installed on local hard drive"**
4. 确保该选项前变为 **红色硬盘图标** ✓

```
组件选择示意图：

┌─────────────────────────────────────┐
│ [+] TortoiseSVN                     │
│ [+] Documentation                   │
│ [🔴] command line client tools  ← 勾选此项！
│ [+] Language packs                  │
└─────────────────────────────────────┘
```

### 步骤 5：完成安装

点击 **Install** 开始安装，等待完成后点击 **Finish**。

---

## 三、验证安装与环境变量配置

### 1️⃣ 验证命令行工具

打开 **命令提示符（CMD）**，输入：

```bash
svn --version
```

**成功显示**：

```
svn, version 1.14.x (rxxxxxx)
   compiled xxx xx xxxx, xx:xx:xx on x86_64-microsoft-windows
```

> [!failure] 如果提示 `'svn' 不是内部或外部命令`
> 说明环境变量未配置，需要按以下步骤手动添加。

---

### 2️⃣ 配置 PATH 环境变量

#### 方法一：自动添加（推荐）

重新运行 TortoiseSVN 安装程序，选择 **Modify**（修改），确保 command line client tools 已勾选，部分版本会自动配置环境变量。

#### 方法二：手动添加

> [!example] 手动配置步骤

| 步骤 | 操作 |
|:-----|:-----|
| 1 | 找到安装目录：`C:\Program Files\TortoiseSVN\bin` |
| 2 | 确认该目录下存在 `svn.exe` 文件 |
| 3 | 右键"此电脑" → 属性 → 高级系统设置 → 环境变量 |
| 4 | 在"系统变量"中找到 **Path**，双击 |
| 5 | 点击"新建"，粘贴路径：`C:\Program Files\TortoiseSVN\bin` |
| 6 | 一路点击"确定"保存 |
| 7 | **重新打开 CMD**，输入 `svn --version` 验证 |

---

## 四、命令行使用指南

### 1️⃣ 创建本地目录

在你想存放代码的位置创建一个空文件夹：

```bash
# 例如创建目录
mkdir D:\work\cross
```

### 2️⃣ 打开命令提示符

按 `Win + R`，输入 `cmd`，回车。

### 3️⃣ 进入目标目录

```bash
cd /d D:\work\cross
```

### 4️⃣ 执行 SVN Checkout 命令

```bash
svn checkout svn://172.16.1.4/车载产品组工作区/C项目开发管理/01开发平台/CAT1/工具/cross .
```

> [!tip] 💡 命令解释
> | 命令部分 | 说明 |
> |:---------|:-----|
> | `svn checkout` | 检出命令（可简写为 `svn co`） |
> | `svn://...` | SVN 服务器地址 |
> | `.` (末尾的点) | 表示下载到当前目录 |
> 
> 如果路径中有中文或空格，建议用英文双引号括起来。

### 5️⃣ 输入账号密码

首次连接服务器时，系统会提示输入用户名和密码：

```bash
# 输入提示示例
Authentication realm: <svn://172.16.1.4:3690> VisualSVN Server
Username: 张冰
Password: zb0819
```

输入后回车即可开始下载。

---

## 五、常用 SVN 命令速查

> [!info] 📋 SVN 命令速查表

| 命令 | 简写 | 功能 | 示例 |
|:-----|:-----|:-----|:-----|
| `svn checkout` | `svn co` | 检出代码 | `svn co URL .` |
| `svn update` | `svn up` | 更新代码 | `svn up` |
| `svn commit` | `svn ci` | 提交代码 | `svn ci -m "说明"` |
| `svn add` | - | 添加文件 | `svn add file.txt` |
| `svn delete` | `svn del` | 删除文件 | `svn del file.txt` |
| `svn status` | `svn st` | 查看状态 | `svn st` |
| `svn log` | - | 查看日志 | `svn log` |
| `svn diff` | - | 查看差异 | `svn diff file.txt` |
| `svn revert` | - | 撤销修改 | `svn revert file.txt` |
| `svn info` | - | 查看信息 | `svn info` |
| `svn list` | `svn ls` | 列出文件 | `svn ls URL` |

---

## 六、常见问题解决

### ❓ 问题 1：`svn` 命令找不到

> [!check] 解决方案
> 检查环境变量 Path 中是否包含 `C:\Program Files\TortoiseSVN\bin`

### ❓ 问题 2：连接服务器失败

> [!check] 解决方案
> 1. 检查服务器地址是否正确
> 2. 检查网络连接是否正常
> 3. 确认账号密码是否正确

### ❓ 问题 3：中文路径乱码

> [!check] 解决方案
> 使用英文双引号包裹路径：`svn co "svn://...中文路径..." .`

### ❓ 问题 4：权限不足

> [!check] 解决方案
> 联系 SVN 管理员确认账号权限配置。

---

## 📊 总结

> [!summary] 安装要点回顾
> 1. **下载正确版本**：根据系统位数选择 x64 或 x86
> 2. **勾选命令行工具**：安装时必须勾选 "command line client tools"
> 3. **配置环境变量**：将 `bin` 目录添加到 Path
> 4. **验证安装**：使用 `svn --version` 确认安装成功
> 5. **检出代码**：使用 `svn checkout` 命令拉取项目

---

> [!tip] 🔗 相关文档
> - [[02_第二周学习笔记/YaXon平台使用.md|YaXon平台使用指南]]
> - [[#常用 SVN 命令速查|SVN命令速查表]]