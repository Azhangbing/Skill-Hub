---
tags:
  - 学习
week: 第8周
created: 2026-04-29
topic: "repo工具安装"
---

# repo安装

> [!summary] 概述
> 本文记录在 Windows 环境下使用 Git Bash 安装 Google `repo` 多仓库管理工具的完整步骤，包括环境准备、脚本下载、Python 适配、国内镜像配置以及常见问题解决。


---

## 1. 安装步骤

### 第一步：确认环境

在 **Git Bash** 中依次运行以下命令，确保基础工具已安装：

```bash
git --version
python3 --version
curl --version
```

如果缺少某个工具，请先安装：

- **Git for Windows**：[https://git-scm.com/download/win](https://git-scm.com/download/win)（安装时勾选 "Add to PATH" 和 "Enable symbolic links"）
- **Python 3**：[https://www.python.org/downloads/](https://www.python.org/downloads/)（安装时勾选 "Add Python to PATH"）


---

### 第二步：创建 bin 目录并加入 PATH

```bash
mkdir -p ~/bin
echo 'export PATH="$HOME/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```


---

### 第三步：下载官方 repo 脚本并适配 Python 3

```bash
cd ~/bin
curl -o repo https://storage.googleapis.com/git-repo-downloads/repo
chmod +x repo
```

> 如果 curl 失败，可以手动访问 [https://storage.googleapis.com/git-repo-downloads/repo](https://storage.googleapis.com/git-repo-downloads/repo) 保存到 `~/bin/repo`。

**强制使用 python3 解释器**（解决 Python 2/3 混用问题）：

```bash
sed -i '1s/python.*/python3/' repo
```

验证首行：

```bash
head -1 repo
```

应该显示 `#!/usr/bin/env python3`。


---

### 第四步：配置国内镜像（加速）

```bash
echo 'export REPO_URL="https://mirrors.tuna.tsinghua.edu.cn/git/git-repo/"' >> ~/.bashrc
source ~/.bashrc
```


---

### 第五步：测试 repo 是否正常

```bash
repo --version
```

若显示版本号（如 `repo launcher version 2.45` 等），说明安装成功。


---

### 第六步：初始化一个项目（示例）

创建一个目录用于存放代码，并执行 `repo init`：

```bash
cd /z                # 或你想要的任何目录
mkdir myproject
cd myproject
repo init -u https://aosp.tuna.tsinghua.edu.cn/platform/manifest -b android-15.0.0_r1
```

> 参数说明：
> - `-u`：清单仓库地址（这里用 AOSP 清华镜像）
> - `-b`：分支名（可选）


---

## 2. 常见问题

| 问题 | 解决方案 |
| ---- | -------- |
| `repo: command not found` | 确认 `~/bin` 已加入 PATH，并重启 Git Bash |
| 长文件名错误 | 以管理员身份运行 Git Bash 并执行 `git config --system core.longpaths true` |
| 符号链接错误 | 在 `repo init` 时加上 `--worktree` 参数：`repo init --worktree -u <url> -b <branch>` |

> [!important] 关键点
> - `repo` 是 Google 开发的多仓库管理工具，常用于 Android 源码下载
> - Windows 环境需确保 Git Bash、Python 3、curl 三者齐备
> - 强制使用 `python3` 解释器可避免 Python 2/3 混用导致的语法错误
> - 配置清华镜像可大幅加速下载速度
> - 遇到符号链接问题优先使用 `--worktree` 参数


---

## 关联笔记

-

---

## 参考资料

- [Git Repo 官方文档](https://gerrit.googlesource.com/git-repo/+/HEAD/README.md)
- [清华 AOSP 镜像使用帮助](https://mirrors.tuna.tsinghua.edu.cn/help/AOSP/)