---
date: 2026-04-30
tags:
  - ML307X
  - 启动流程
  - 调用链
  - 代码分析
aliases:
  - 系统启动调用链
  - main到yx_load_app_modules
---

# 🔗 从系统main到应用层yx_load_app_modules的完整调用链

> [!abstract] 📋 文档概述
> 本文档详细记录 ML307X 平台从系统层 `main()` 函数到业务层 `yx_load_app_modules()` 的完整函数调用链路，帮助理解系统启动流程。

---

## 📑 目录

- [[#一、系统层 main 入口]]
- [[#二、SDK框架初始化]]
- [[#三、雅迅适配层入口]]
- [[#四、框架主任务]]
- [[#五、业务模块加载]]
- [[#六、调用链汇总]]

---

## 一、系统层 main 入口

> [!info] 📍 入口文件
> **路径**：`kernel/appstart/src/main.c:266`

```c
int main(void)
{
    version_identify();          // 版本识别
    osKernelInitialize();        // RTOS内核初始化
    mempool_init();              // 内存池初始化
    posix_device_init();         // POSIX设备注册
    system_init();               // 系统硬件初始化
    app_start();                 // ⬇️ 调用注册表中的初始化函数
    custom_app_start();          // ⬇️ 跳转到APP入口
}
```

| 序号 | 函数 | 说明 |
|:-----|:-----|:-----|
| 1️⃣ | `version_identify()` | 识别芯片/固件版本信息 |
| 2️⃣ | `osKernelInitialize()` | FreeRTOS 内核初始化 |
| 3️⃣ | `mempool_init()` | 分配系统内存池 |
| 4️⃣ | `posix_device_init()` | 注册 POSIX 标准设备接口 |
| 5️⃣ | `system_init()` | 初始化外设驱动 |
| 6️⃣ | `app_start()` | 执行注册表中的初始化函数 |
| 7️⃣ | `custom_app_start()` | 跳转到应用层入口 |

---

## 二、SDK框架初始化

### 2.1 app_start()

> [!info] 📍 文件路径
> `kernel/appstart/src/main.c:88`

```c
// 遍历 __appRegTable_start__ 到 __appRegTable_end__
// 按优先级 HIGH → MIDDLE → LOW 依次执行注册的初始化函数
```

**执行逻辑**：
- 遍历应用注册表
- 按优先级顺序执行初始化函数
- 其中包含 `demo_framework_init()`（通过 `application_init` 宏注册）

### 2.2 demo_framework_init()

> [!info] 📍 文件路径
> `project/default/src/demo_framework.c:139`

```c
void demo_framework_init(void)
{
    // 创建 init_task 线程
    osThreadNew(init_task, NULL, &attr);
}
```

### 2.3 init_task()

> [!info] 📍 文件路径
> `project/default/src/demo_framework.c:125`

```c
void init_task(void *arg)
{
    fk_application_init(NULL);     // ⬇️ 调用雅迅APP入口
}
```

---

## 三、雅迅适配层入口

### 3.1 fk_application_init()

> [!info] 📍 文件路径
> `APP/gps_lite3.5/al/chips/sia/entry/yx_ia_entry.c:36`

```c
void fk_application_init(void *argv)
{
    yx_fw_main(argv);              // ⬇️ 调用框架入口
}
```

---

## 四、框架主任务

### 4.1 yx_fw_main()

> [!info] 📍 文件路径
> `APP/gps_lite3.5/al/modules/fw/fw_main.c:167`

```c
void yx_fw_main(void *argv)
{
    yx_debug_init();
    yx_ia_usernv_init();
    // 创建主任务
    yx_ia_sys_task_create(..., fw_main_task_run, NULL);
}
```

### 4.2 fw_main_task_run()

> [!info] 📍 文件路径
> `APP/gps_lite3.5/al/modules/fw/fw_main.c:242`

```c
void fw_main_task_run(void *arg)
{
    fw_load_modules();             // ⬇️ 加载所有模块
    fw_init();                     // 初始化所有模块
    fw_start();                    // 启动所有模块
    core_msg_loop_run();           // 消息循环
}
```

| 序号 | 函数 | 说明 |
|:-----|:-----|:-----|
| 1️⃣ | `fw_load_modules()` | 加载所有模块 |
| 2️⃣ | `fw_init()` | 初始化所有模块 |
| 3️⃣ | `fw_start()` | 启动所有模块 |
| 4️⃣ | `core_msg_loop_run()` | 进入消息循环 |

---

## 五、业务模块加载

### 5.1 fw_load_modules()

> [!info] 📍 文件路径
> `APP/gps_lite3.5/al/modules/fw/fw_main.c:272`

```c
void fw_load_modules(void)
{
    fw_load_func_modules();        // 加载功能模块（HAL层）
    yx_load_app_modules(NULL);     // ⬇️ 加载业务模块（APP层）
}
```

### 5.2 yx_load_app_modules()

> [!info] 📍 文件路径
> `APP/gps_lite3.5/app/appmain/app_main.c:114`

```c
void yx_load_app_modules(void *arg)
{
    REG_APP_MODULE(test);          // 测试模块
    REG_APP_MODULE(storemgr);      // 存储管理
    REG_APP_MODULE(bms);           // 电池管理
    REG_APP_MODULE(tsp);           // TSP平台交互
    REG_APP_MODULE(its);           // 智能交通
    REG_APP_MODULE(alarm);         // 报警处理
    REG_APP_MODULE(vcs);           // 车辆控制
    REG_APP_MODULE(bt_app);        // 蓝牙应用
    REG_APP_MODULE(yx_proto);      // 协议处理
    REG_APP_MODULE(drv_record);    // 行驶记录
    // ... 其他业务模块
}
```

---

## 六、调用链汇总

### 📊 调用链总览

```mermaid
flowchart TD
    A["main()<br/>kernel/appstart/src/main.c:266"] --> B["app_start()<br/>main.c:88"]
    A --> C["custom_app_start()"]
    B --> D["demo_framework_init()<br/>project/default/src/demo_framework.c:139"]
    D --> E["init_task()<br/>demo_framework.c:125"]
    E --> F["fk_application_init()<br/>APP/.../yx_ia_entry.c:36"]
    F --> G["yx_fw_main()<br/>APP/.../fw/fw_main.c:167"]
    G --> H["fw_main_task_run()<br/>fw_main.c:242"]
    H --> I["fw_load_modules()<br/>fw_main.c:272"]
    H --> J["fw_init()"]
    H --> K["fw_start()"]
    H --> L["core_msg_loop_run()"]
    I --> M["fw_load_func_modules()<br/>功能模块"]
    I --> N["yx_load_app_modules()<br/>app_main.c:114"]
    N --> O["REG_APP_MODULE()<br/>业务模块注册"]
```

### 📝 简化调用链

```
main()
  └─ app_start()
       └─ demo_framework_init()
            └─ init_task()
                 └─ fk_application_init()
                      └─ yx_fw_main()
                           └─ fw_main_task_run()
                                ├─ fw_load_modules()
                                │    ├─ fw_load_func_modules()    (HAL层)
                                │    └─ yx_load_app_modules()     (APP层)
                                ├─ fw_init()
                                ├─ fw_start()
                                └─ core_msg_loop_run()           (消息循环)
```

---

> [!tip] 🔗 相关文档
> - [[C_XINYI_307X代码架构解析]]
> - [[芯翼CAT1-ML307X平台开发环境搭建]]