---
date: 2026-04-30
tags:
  - ML307X
  - CAT1
  - 芯翼科技
  - 代码架构
  - 嵌入式开发
  - 模块化设计
aliases:
  - ML307X架构解析
  - XINYI代码架构
---

# 🏗️ C_XINYI_307X 代码架构解析

> [!abstract] 📋 文档概述
> 本文档详细解析基于芯翼 CAT1-ML307X 平台的两轮车智能终端项目代码架构，采用**模块化分层设计**，适用于电动自行车/电动摩托车的智能终端开发。

---

## 📑 目录

- [[#项目架构概览]]
- [[#分层架构设计]]
- [[#SDK层结构]]
- [[#硬件抽象层(HAL)结构]]
- [[#业务层结构]]
- [[#系统启动流程]]
- [[#核心功能总结]]
- [[#数据流向分析]]

---

## 项目架构概览

### 📁 目录结构

![[Pasted image 20260430112543.png]]

| 目录 | 说明 |
|:-----|:-----|
| `APP/` | YX自研业务代码 |
| `config/` | 配置文件 |
| `cross/` | 交叉编译工具链 |
| `osdrv/` | 芯翼SDK |
| `build_yaxon_new.bat` | 编译工具脚本 |

### 📦 osdrv 子目录

```
osdrv/
└── firmware/
    ├── makepkg/          # 固件打包工具
    └── XY4100LC/         # XY4100LC芯片SDK
```

---

## 分层架构设计

> [!info] 四层架构模型

| 层级 | 目录 | 职责 |
|:---------|:-----------|:--------------------|
| **芯片SDK层** | `osdrv/firmware/XY4100LC` | 芯翼官方SDK，提供底层驱动、内核、协议栈 |
| **硬件抽象层** | `APP/gps_lite3.5/al` | 硬件抽象，屏蔽芯片差异，提供统一接口 |
| **业务应用层** | `APP/gps_lite3.5/app` | 两轮车业务功能模块 |
| **配置层** | `APP/gps_lite3.5/app/custom` | 产品特性配置、功能裁剪 |

### 🔄 架构图

```
┌─────────────────────────────────────────────────────────────┐
│                      配置层 (custom)                         │
│            产品特性配置、功能裁剪                              │
├─────────────────────────────────────────────────────────────┤
│                    业务应用层 (app)                           │
│     TSP | BMS | VCS | Alarm | ITS | BT | 协议 | 存储         │
├─────────────────────────────────────────────────────────────┤
│                 硬件抽象层 (HAL)                              │
│   core | gnss | net | m2m | storage | fw | sensor | power   │
├─────────────────────────────────────────────────────────────┤
│                    SDK层 (XY4100LC)                          │
│      kernel | application | boot | lib | project            │
└─────────────────────────────────────────────────────────────┘
```

---

## SDK层结构

> [!info] `osdrv/firmware/XY4100LC`

| 模块 | 功能 |
|:-----|:-----|
| **kernel/** | 内核层（FreeRTOS、HAL驱动、电源管理、GNSS核心） |
| **application/** | 应用框架（AT命令、HTTP/MQTT/阿里云/腾讯云、音频、FOTA升级） |
| **boot/** | 二级启动引导程序 |
| **lib/** | 预编译库文件 |
| **project/** | 工程模板和示例 |

---

## 硬件抽象层(HAL)结构

> [!info] `APP/gps_lite3.5/al/modules`

### 🧩 核心功能模块

| 模块 | 功能 | 关键文件 |
|:-----|:-----|:---------|
| **core** | 核心消息分发 | `core_msg.c` |
| **gnss** | GPS/北斗定位 | `gnss.c` (81KB) |
| **net** | 网络通信(GPRS/TCP/HTTP) | `yx_net_tcp.c`, `yx_net_http.c` |
| **m2m** | 核间通讯(AP核与通信核) | `m2m_man.c` |
| **storage** | 参数存储(NVM) | `storage.c` |
| **fw** | 固件管理 | `fw_main.c` |
| **gsm** | GSM通信 | - |
| **sensor** | 传感器(震动/碰撞检测) | - |
| **odometer** | 里程统计 | - |
| **yx_power** | 电源管理 | - |

### 🔌 芯片适配层

> [!note] `al/chips/sia/`

| 接口类型 | 功能说明 |
|:---------|:---------|
| GPIO/UART/I2C/SPI | 硬件驱动接口 |
| GPRS/HTTP/MQTT/LBS | 通信接口 |
| FOTA | 升级接口 |
| 文件系统 | 存储接口 |

---

## 业务层结构

> [!info] `APP/gps_lite3.5/app/modules`

### 🚀 两轮车专用业务模块

| 模块 | 功能 | 说明 |
|:-----|:-----|:-----|
| **tsp** | TSP平台交互 | 与云端平台通信，包含 `ebike`、`yx_ota` 子模块 |
| **bms** | 电池管理 | 电池数据采集、状态上报 |
| **vcs** | 车辆控制 | 车辆控制业务（锁车/解锁等） |
| **alarm** | 报警处理 | 异常报警（震动、位移、低电量等） |
| **its** | ITS智能交通 | 智能交通服务 |
| **factorytool** | 工厂工具 | 生产测试工具 |
| **bt_app** | 蓝牙应用 | 蓝牙通信功能 |
| **yx_proto** | 协议处理 | 485/SIF/XATL/XDAO等协议 |
| **storemgr** | 存储管理 | 数据存储管理 |
| **drv_record** | 行驶记录 | 行驶轨迹记录 |

---

## 系统启动流程

> [!important] 🔑 启动入口详解

### 📍 系统层 main 函数入口

> [!info] 入口文件
> **路径**：`kernel/appstart/src/main.c:266`

这是系统启动的**主入口**，负责：

| 初始化步骤 | 函数 | 说明 |
|:-----------|:-----|:-----|
| 1️⃣ 版本识别 | `version_identify()` | 识别芯片/固件版本 |
| 2️⃣ OS内核初始化 | `osKernelInitialize()` | FreeRTOS内核启动 |
| 3️⃣ 内存池初始化 | `mempool_init()` | 分配系统内存池 |
| 4️⃣ POSIX设备初始化 | `posix_device_init()` | 标准设备接口 |
| 5️⃣ 系统初始化 | `system_init()` | 外设、驱动初始化 |
| 6️⃣ 应用启动 | `app_start()` | 启动应用框架 |
| 7️⃣ 自定义启动 | `custom_app_start()` | 产品定制初始化 |

### 📍 应用层主入口

> [!info] 入口文件
> **路径**：`APP/gps_lite3.5/app/appmain/app_main.c`

这是**业务层主入口**，负责将所有业务模块加载到主框架。

### 🔄 启动流程图

```mermaid
flowchart TD
    A[系统层 main.c] --> B[version_identify<br/>版本识别]
    B --> C[osKernelInitialize<br/>OS内核初始化]
    C --> D[mempool_init<br/>内存池初始化]
    D --> E[posix_device_init<br/>POSIX设备初始化]
    E --> F[system_init<br/>系统初始化]
    F --> G[app_start<br/>应用框架启动]
    G --> H[custom_app_start<br/>产品定制初始化]
    H --> I[app_main.c<br/>业务层入口]
    I --> J[加载业务模块<br/>TSP/BMS/VCS等]
    J --> K[✅ 系统正常运行]
```

### 📝 启动流程总结

```
系统层 main → 初始化 → app_start() → custom_app_start() → 应用层入口
```

> [!tip] 💡 关键点
> - **系统层**负责底层硬件和OS初始化
> - **应用层**负责业务模块的加载和运行
> - **custom层**提供产品定制化初始化入口

---

## 核心功能总结

### 📊 功能模块对照表

| 功能 | 实现模块 | 通信方式 |
|:-----|:---------|:---------|
| **定位追踪** | GNSS模块 | GPS/北斗卫星 |
| **数据上报** | TSP模块 + Net模块 | LTE Cat1 → 云平台 |
| **电池监控** | BMS模块 | UART/485与BMS通信 |
| **车辆控制** | VCS模块 | 远程控制指令 |
| **报警检测** | Alarm + Sensor | 震动/位移传感器 |
| **远程升级** | FOTA | HTTP下载升级包 |
| **蓝牙功能** | BT_APP | BLE通信 |
| **行驶记录** | drv_record | 本地存储轨迹 |

---

## 数据流向分析

### 📡 定位数据流

```mermaid
flowchart LR
    A[GNSS卫星] --> B[gnss模块]
    B --> C[core消息分发]
    C --> D[业务处理]
    D --> E[net模块]
    E --> F[LTE Cat1]
    F --> G[云平台]
```

### 🔋 电池数据流

```mermaid
flowchart LR
    A[BMS硬件] -->|UART/485| B[bms模块]
    B --> C[core消息分发]
    C --> D[状态判断]
    D --> E{异常?}
    E -->|是| F[alarm模块]
    E -->|否| G[tsp上报]
    F --> G
    G --> H[云平台]
```

### 🚗 车辆控制流

```mermaid
flowchart LR
    A[云平台指令] --> B[net模块接收]
    B --> C[tsp模块解析]
    C --> D[vcs模块执行]
    D --> E[硬件控制]
    E --> F[车辆响应]
    F --> G[状态上报]
    G --> A
```

---

## 📊 总结

> [!summary] 架构特点
> 
> 本项目采用**模块化分层架构**，具有以下特点：
> 
> | 特点 | 说明 |
> |:-----|:-----|
> | **高内聚低耦合** | 各模块职责明确，接口清晰 |
> | **硬件抽象** | HAL层屏蔽芯片差异，便于移植 |
> | **消息驱动** | core模块统一分发，解耦模块间通信 |
> | **可配置** | custom层支持产品特性裁剪 |
> 
> 适用于 **电动自行车/电动摩托车智能终端**，实现定位追踪、远程监控、电池管理、车辆控制等完整功能。

---

> [!tip] 🔗 相关文档
> - [[芯翼CAT1-ML307X平台开发环境搭建]]
> - [[docs/PP_Parameters_Documentation.md|PP参数详解]]
> - [[docs/Terminal_Communication_Flow.md|终端通信流程详解]]